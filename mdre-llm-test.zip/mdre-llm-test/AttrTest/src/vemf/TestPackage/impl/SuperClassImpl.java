/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.SuperClass;
import TestPackage.TestPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SuperClassImpl extends EObjectImpl implements SuperClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} //SuperClassImpl
