/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
/**
 */
package TestPackage.impl;

import TestPackage.TestPackagePackage;
import TestPackage.UberClass;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class UberClassImpl extends EObjectImpl implements UberClass
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClassImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} //UberClassImpl
