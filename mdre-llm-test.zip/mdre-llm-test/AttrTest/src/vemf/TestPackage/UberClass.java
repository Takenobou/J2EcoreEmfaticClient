/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model abstract="true"
 * @generated
 */
public interface UberClass extends EObject
{
} // UberClass
