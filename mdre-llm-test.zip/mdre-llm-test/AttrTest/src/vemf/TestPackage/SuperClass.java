/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model abstract="true"
 * @generated
 */
public interface SuperClass extends EObject
{
} // SuperClass
