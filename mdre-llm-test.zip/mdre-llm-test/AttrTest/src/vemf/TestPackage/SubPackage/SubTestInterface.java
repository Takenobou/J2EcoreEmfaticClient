/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.SubPackage.SubPackagePackage#getSubTestInterface()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface SubTestInterface extends EObject
{
} // SubTestInterface
