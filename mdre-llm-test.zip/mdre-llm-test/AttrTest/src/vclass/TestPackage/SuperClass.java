/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getSuperClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class SuperClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
