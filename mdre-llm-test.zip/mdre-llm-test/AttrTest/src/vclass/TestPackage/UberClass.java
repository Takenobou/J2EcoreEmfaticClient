/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see TestPackage.TestPackagePackage#getUberClass()
 * @model kind="class" abstract="true"
 * @generated
 */
public abstract class UberClass extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
