/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Uber Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class UberClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UberClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.UBER_CLASS;
	}

} // UberClass
