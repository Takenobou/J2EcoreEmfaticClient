/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
/**
 */
package TestPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public abstract class SuperClass extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperClass()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return TestPackagePackage.Literals.SUPER_CLASS;
	}

} // SuperClass
