/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
/**
 */
package TestPackage.SubPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub Test Interface</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public interface SubTestInterface extends Object
{
} // SubTestInterface
