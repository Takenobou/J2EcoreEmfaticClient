/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
/**
 */
package petrinet;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see petrinet.PetrinetPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject
{
} // Token
