/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Object
 * @generated
 */
public class SSC extends Object implements Object
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
