/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
/**
 */
package main.sub.subsub.impl;

import main.sub.subsub.SSC;
import main.sub.subsub.SubsubPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SSCImpl extends EObjectImpl implements SSC
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSCImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} //SSCImpl
