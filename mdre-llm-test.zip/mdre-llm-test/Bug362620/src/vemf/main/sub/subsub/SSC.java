/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model
 * @generated
 */
public interface SSC extends EObject
{
} // SSC
