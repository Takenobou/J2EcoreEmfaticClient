/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
/**
 */
package main.sub.subsub;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SSC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see main.sub.subsub.SubsubPackage#getSSC()
 * @model kind="class"
 * @generated
 */
public class SSC extends EObjectImpl implements EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SSC()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return SubsubPackage.Literals.SSC;
	}

} // SSC
