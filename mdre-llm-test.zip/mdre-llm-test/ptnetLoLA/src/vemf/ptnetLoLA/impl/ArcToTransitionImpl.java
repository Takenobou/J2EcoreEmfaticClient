/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
/**
 */
package ptnetLoLA.impl;

import org.eclipse.emf.ecore.EClass;

import ptnetLoLA.ArcToTransition;
import ptnetLoLA.PtnetLoLAPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArcToTransitionImpl extends ArcImpl implements ArcToTransition
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransitionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} //ArcToTransitionImpl
