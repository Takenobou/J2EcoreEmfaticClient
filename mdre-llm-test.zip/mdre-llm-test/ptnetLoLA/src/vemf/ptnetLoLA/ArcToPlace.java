/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToPlace()
 * @model
 * @generated
 */
public interface ArcToPlace extends Arc
{
} // ArcToPlace
