/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
/**
 */
package ptnetLoLA;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model
 * @generated
 */
public interface ArcToTransition extends Arc
{
} // ArcToTransition
