/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ptnetLoLA.PtnetLoLAPackage#getArcToTransition()
 * @model kind="class"
 * @generated
 */
public class ArcToTransition extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToTransition()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_TRANSITION;
	}

} // ArcToTransition
