/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
/**
 */
package ptnetLoLA;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arc To Place</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @generated
 */
public class ArcToPlace extends Arc
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArcToPlace()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return PtnetLoLAPackage.Literals.ARC_TO_PLACE;
	}

} // ArcToPlace
