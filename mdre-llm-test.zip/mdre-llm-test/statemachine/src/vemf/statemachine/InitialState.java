/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
/**
 */
package statemachine;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getInitialState()
 * @model annotation="diagraph node='null'"
 * @generated
 */
public interface InitialState extends State
{
} // InitialState
