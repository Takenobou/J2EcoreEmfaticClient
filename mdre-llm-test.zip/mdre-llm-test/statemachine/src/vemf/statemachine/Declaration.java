/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
/**
 */
package statemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see statemachine.StatemachinePackage#getDeclaration()
 * @model abstract="true"
 *        annotation="diagraph node='null'"
 * @generated
 */
public interface Declaration extends EObject
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void printReachable();

} // Declaration
